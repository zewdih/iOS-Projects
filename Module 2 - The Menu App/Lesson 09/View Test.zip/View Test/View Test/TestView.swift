//
//  TestView.swift
//  View Test
//
//  Created by Chris Ching on 2023-03-30.
//

import SwiftUI

struct TestView: View {
    var body: some View {
        
        CustomButton(buttonText: "Enroll", showSubtext: true)
    }
}

struct TestView_Previews: PreviewProvider {
    static var previews: some View {
        TestView()
    }
}
