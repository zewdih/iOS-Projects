//
//  View_TestApp.swift
//  View Test
//
//  Created by Chris Ching on 2023-03-30.
//

import SwiftUI

@main
struct View_TestApp: App {
    var body: some Scene {
        WindowGroup {
            TestView()
        }
    }
}
