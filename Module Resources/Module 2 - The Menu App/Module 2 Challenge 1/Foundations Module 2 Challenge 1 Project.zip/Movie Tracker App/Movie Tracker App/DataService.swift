//
//  DataService.swift
//  Movie Tracker App
//
//  See LICENSE folder for this project's licensing information.
//
//  Created by CodeWithChris (https://codewithchris.com)
//  Copyright © 2023 CodeWithChris. All rights reserved.

import Foundation

struct DataService {
    
    func getTestData() -> [Movie] {
        return [Movie(title: "Mission Impossible",
                      imageName: "missionimpossible",
                      rating: 4.8),
                Movie(title: "Captain America",
                      imageName: "captainamerica",
                      rating: 3.5),
                Movie(title: "Home Alone",
                      imageName: "homealone",
                      rating: 5.0),
                Movie(title: "Mario Bros",
                      imageName: "mariobros",
                      rating: 4.2),
                Movie(title: "Dune",
                      imageName: "dune",
                      rating: 3.9)
        ]
    }
}
