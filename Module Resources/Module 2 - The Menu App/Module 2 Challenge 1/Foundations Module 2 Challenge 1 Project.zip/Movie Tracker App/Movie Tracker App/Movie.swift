//
//  Movie.swift
//  Movie Tracker App
//
//  See LICENSE folder for this project's licensing information.
//
//  Created by CodeWithChris (https://codewithchris.com)
//  Copyright © 2023 CodeWithChris. All rights reserved.

import Foundation

struct Movie: Identifiable {
    
    var id: UUID = UUID()
    var title: String
    var imageName: String
    var rating: Double
    
}
