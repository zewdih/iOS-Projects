//
//  ContentView.swift
//  Movie Tracker App
//
//  See LICENSE folder for this project's licensing information.
//
//  Created by CodeWithChris (https://codewithchris.com)
//  Copyright © 2023 CodeWithChris. All rights reserved.

import SwiftUI

struct ContentView: View {
    
    @State var movies = [Movie]()
    
    var body: some View {
        
        ZStack {
            Color.black
                .ignoresSafeArea()
            
            List(movies) { m in
                
                VStack (alignment: .center) {
                    Image(m.imageName)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                    Text(m.title)
                        .foregroundStyle(Color.white)
                }
                .padding(.bottom, 20)
                .listRowBackground(Color.clear)
            }
            
            .listStyle(.plain)
            .onAppear {
                movies = DataService().getTestData()
            }
        }
    }
}

#Preview {
    ContentView()
}
