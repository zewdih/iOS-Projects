//
//  War_Card_GameApp.swift
//  War Card Game
//
//  Created by Chris Ching on 2022-12-02.
//

import SwiftUI

@main
struct War_Card_GameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
