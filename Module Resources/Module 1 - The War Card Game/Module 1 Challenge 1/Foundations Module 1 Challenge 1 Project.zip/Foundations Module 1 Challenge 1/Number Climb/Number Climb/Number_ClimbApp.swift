//
//  Number_ClimbApp.swift
//  Number Climb
//
//  See LICENSE folder for this project's licensing information.
//
//  Created by CodeWithChris (https://codewithchris.com)
//  Copyright © 2023 CodeWithChris. All rights reserved.

import SwiftUI

@main
struct Number_ClimbApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
