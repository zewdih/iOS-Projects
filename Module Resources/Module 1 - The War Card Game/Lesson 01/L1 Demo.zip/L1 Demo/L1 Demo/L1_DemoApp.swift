//
//  L1_DemoApp.swift
//  L1 Demo
//
//  Created by Chris Ching on 2022-11-09.
//

import SwiftUI

@main
struct L1_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
